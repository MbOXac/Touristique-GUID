import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'screens/main_navigation.dart';
import 'screens/login_page.dart';
import 'screens/admin/admin_dashboard.dart';
import 'services/admin_service.dart';

/// Listens to Firebase auth state and routes the user to:
///  • LoginPage       — not signed in
///  • AdminDashboard  — signed in AND role == "admin" in Firestore
///  • MainNavigation  — signed in, regular user (unchanged)
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.hasData && snapshot.data != null) {
          // User is logged in — check their role asynchronously.
          return FutureBuilder<bool>(
            future: AdminService().isCurrentUserAdmin(),
            builder: (context, adminSnap) {
              if (adminSnap.connectionState == ConnectionState.waiting) {
                return const Scaffold(
                  body: Center(child: CircularProgressIndicator()),
                );
              }
              final isAdmin = adminSnap.data ?? false;
              if (isAdmin) {
                return const AdminDashboard();
              }
              // Regular user — keep original flow.
              return const MainNavigation();
            },
          );
        }

        // User is not logged in.
        return const LoginPage();
      },
    );
  }
}